// rewardController.js
const { Reward, User, Habit } = require('../models');

const getUserRewards = async (req, res) => {
  try {
    const rewards = await Reward.findAll({
      where: { userId: req.user.id },
      order: [['createdAt', 'DESC']]
    });
    res.json(rewards);
  } catch (err) {
    console.error('GET /rewards error:', err);
    res.status(500).json({ error: 'Gagal mengambil data rewards' });
  }
};

const getTotalPoints = async (req, res) => {
  try {
    const rewards = await Reward.findAll({ where: { userId: req.user.id } });
    const totalPoints = rewards.reduce((sum, r) => sum + r.points, 0);

    let badge = null;
    if (totalPoints >= 100) badge = 'Master Habit';
    else if (totalPoints >= 50) badge = 'Disiplin';
    else badge = 'Semangat lagi';

    await User.update({ badge }, { where: { id: req.user.id } });
    res.json({ totalPoints, badge });
  } catch (err) {
    console.error('GET /rewards/total error:', err);
    res.status(500).json({ error: 'Gagal menghitung total poin' });
  }
};

const createRewardIfEligible = async (req, res) => {
  try {
    const completedHabits = await Habit.count({
      where: { userId: req.user.id, completed: true }
    });

    if (completedHabits >= 5) {
      const reward = await Reward.create({
        title: 'Reward atas konsistensi!',
        points: 10,
        userId: req.user.id
      });

      await Habit.update({ completed: false }, {
        where: { userId: req.user.id, completed: true }
      });

      return res.json({ message: 'Reward berhasil diklaim!', reward });
    }
    res.status(400).json({ message: 'Belum memenuhi syarat klaim reward.' });
  } catch (err) {
    console.error('POST /rewards/claim error:', err);
    res.status(500).json({ error: 'Gagal klaim reward' });
  }
};

module.exports = {
  getUserRewards,
  getTotalPoints,
  createRewardIfEligible
};
